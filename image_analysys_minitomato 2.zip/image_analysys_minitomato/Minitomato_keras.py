
# coding: utf-8

# In[82]:


from keras.models import Sequential


# In[83]:


from keras.layers import Convolution2D, MaxPooling2D


# In[84]:


from keras.layers import Activation, Dropout, Flatten, Dense


# In[85]:


from keras.utils import np_utils


# In[86]:


import numpy as np


# Classification directory

# In[87]:


root_dir = "./image"


# In[88]:


categories = ["grown_tomato", "non_tomato", "young_tomato"]


# In[89]:


nb_classes = len(categories)


# In[90]:


image_size = 50


# In[91]:


X_train, X_test, Y_train, Y_test = np.load("./image/tomato.npy")


# In[92]:


X_train


# Load data

# In[93]:


def main():
    X_train, X_test, Y_train, Y_test = np.load("./image/tomato.npy")
    #Normalization
    X_train = X_train.astype("float") / 256
    X_test = X_test.astype("float") / 256
    #Keras seems to treat the label as a vector with 0or1 as its element, not as a numerical value. 
    #That is, assuming that the target for a given sample is "3", [0, 0, 0, 1, 0, 0, 0, 0, 0, 0]
    Y_train = np_utils.to_categorical(Y_train, nb_classes)
    Y_test = np_utils.to_categorical(Y_test, nb_classes)
    #Tran model and evaluate
    model = model_train(X_train, Y_train)
    model_eval(model, X_test, Y_test)


# Create Model

# In[102]:


def build_model(in_shape):
    
    #model = Sequential()
    #model.add(Convolution2D(32, (3, 3), border_mode='same', input_shape=in_shape))
    #model.add(Activation('relu'))
    #model.add(MaxPooling2D(pool_size=(2, 2)))
    #model.add(Dropout(0.25))
    #model.add(Convolution2D(64, (3, 3), border_mode='same'))
    #model.add(Activation('relu'))
    #model.add(Convolution2D(64, (3, 3)))
    #model.add(MaxPooling2D(pool_size=(2, 2)))
    #model.add(Dropout(0.25))
    #model.add(Flatten())
    #model.add(Dense(512))
    #model.add(Activation('relu'))
    #model.add(Dropout(0.5))
    #model.add(Activation('softmax'))
    #model.compile(loss='binary_crossentropy', optimizer = 'rmsprop', metrics=['accuracy'])
    
    model = Sequential()

    model.add(Convolution2D(32, (3, 3), padding='same', input_shape=in_shape))
    model.add(Activation('relu'))
    model.add(Convolution2D(64, (3, 3)))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Convolution2D(64, (3, 3), padding="same"))
    model.add(Activation('relu'))
    model.add(Convolution2D(64, (3, 3)))
    model.add(Activation('relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Flatten())
    model.add(Dense(512))
    model.add(Activation('relu'))
    model.add(Dropout(0.5))

    model.add(Dense(3))
    model.add(Activation('softmax'))
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model


# Train Model

# In[103]:


def model_train(X, Y):
    model = build_model(X.shape[1:])
    model.fit(X, Y, batch_size=32, epochs=30)
    #Save model
    hdf5_file = "./image/minitomato-model.hdf5"
    model.save_weights(hdf5_file)
    return model


# Evaluate Model

# In[104]:


def model_eval(model, X, Y):
    score = model.evaluate(X, Y)
    print('loss=', score[0])
    print('accuracy', score[0])


# In[105]:


if __name__ == "__main__":
    main()

