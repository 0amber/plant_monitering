
# coding: utf-8

# In[3]:


from PIL import Image


# In[5]:


import os, glob


# In[6]:


import numpy as np


# In[7]:


import random, math


# Select data to be classified

# In[8]:


root_dir = "./image/"


# In[9]:


categories = ["grown_tomato", "non_tomato", "young_tomato"]


# In[10]:


nb_classes = len(categories)


# In[11]:


image_size = 50


# Read Image

# In[12]:


X = [] #image


# In[13]:


Y = [] #label


# In[59]:


def add_sample(cat, fname, is_train):
    img = Image.open(fname)
    img = img.convert("RGB") #change color mode
    img = img.resize((image_size, image_size))
    data = np.array(img)
    X.append(data)
    Y.append(cat)
    if not is_train:
        return
    #Add data with a slightly different angle
    #Rotate slightly
    for ang in range(-20, 20, 5):
        img2 = img.rotate(ang)
        data = np.array(img2)
        X.append(data)
        Y.append(cat)
        #reversal
        img2 = img2.transpose(Image.FLIP_LEFT_RIGHT)
        data = np.array(img2)
        X.append(data)
        Y.append(cat)


# In[37]:


def make_sample(files, is_train):
    global X, Y
    X = []; Y = []
    for cat, fname in files:
        add_sample(cat, fname, is_train)
    return np.array(X), np.array(Y)


# Collect files divided for each directory

# In[38]:


allfiles = []


# In[52]:


for idx, cat in enumerate(categories):
    image_dir = root_dir + "/" + cat
    files = glob.glob(image_dir + "/*.jpg")
    for f in files:
        allfiles.append((idx, f))


# In[53]:


allfiles


# Shuffle and divide it into learning data and test data

# In[54]:


random.shuffle(allfiles)


# In[55]:


th = math.floor(len(allfiles) * 0.6)


# In[56]:


train = allfiles[0:th]


# In[57]:


test = allfiles[th:]


# In[60]:


X_train, Y_train = make_sample(train, True)


# In[61]:


X_test, Y_test = make_sample(test, True)


# In[62]:


xy = (X_train, X_test, Y_train, Y_test)


# In[63]:


np.save("./image/tomato.npy", xy)


# In[64]:


print("ok", len(Y_train))

