
# coding: utf-8

# In[1]:


import Minitomato_keras as minitomato


# In[2]:


import sys, os


# In[3]:


from PIL import Image


# In[4]:


import numpy as np


# Get file name from the command line

# In[5]:


if len(sys.argv) <= 1:
    print("Minitomato_checker.py FILENAME")
    quit()


# In[6]:


image_size = 50


# In[7]:


categories = ["grown_tomato", "non_tomato", "young_tomato"]


# In[8]:


pick_timing = ["Perfect", "Impossible", "Not yet"]


# Convert input image to Numpy

# In[9]:


X = []


# In[10]:


files =  []


# In[12]:


for fname in sys.argv[1:]:
    img = Image.open(fname)
    img = img.convert("RGB")
    img = img.resize((image_size, image_size))
    in_data = np.asarray(img)
    X.append(in_data)
    files.append(fname)


# In[13]:


X = np.array(X)


# CNNのモデルを構築

# In[14]:


model = minitomato.build_model(X.shape[1:])


# In[15]:


model.load_weights("./image/minitomato-model.hdf5")


# Predict data

# In[16]:


html = ""


# In[17]:


pre = model.predict(X)


# In[19]:


for i, p in enumerate(pre):
    y = p.argmax()
    print("+ input:", files[i])
    print("| Growth of Mini tomato:", categories[i])
    print("| Picking timing:",pick_timing[i])
    html += """
        <h3>input:{0}</h3>
        <div>
            <p><img src="{1}" width=300></p>
            <p>Growth of Mini tomato:{2}</p>
            <p>Picking timing:{3}</p>
        </div>
    """.format(os.path.basename(files[i]), files[i], categories[y], pick_timing[i])


# Save report

# In[20]:


html = "<html><body style='text-align:center;'>" +     "<style> p {magin:0; padding:0; } </style>" +     html + "</body></html>"
with open("Mini_tomato_pikking_time_result.html", "w") as f:
    f.write(html)

