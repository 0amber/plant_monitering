
# coding: utf-8

# In[1]:


import sys, os, re, time


# In[2]:


import urllib.request as req


# In[3]:


import urllib.parse as parse


# In[7]:


import json


# Designate URL API

# In[5]:


PHOTOZOU_API = "https://api.photozou.jp/rest/search_public.json"


# In[6]:


CACHE_DIR = "./image/cache"


# Search image using フォト蔵 API

# In[8]:


def search_photo(keyword, offset=0, limit=100):
    #Format API query
    keyword_enc = parse.quote_plus(keyword) #Replace the value in HTML format with the plus sign "+" for inserting the query string into the URL
    q = "keyword={0}&offset{1}&limit={2}".format(
    keyword_enc, offset, limit)
    url = PHOTOZOU_API + "?" + q
    #Create a directory for caching
    if not os.path.exists(CACHE_DIR):
        os.makedirs(CACHE_DIR)
    cache = CACHE_DIR + "/" + re.sub(r'[^a-zA-Z0-9\%\#]+', '_', url)
    if os.path.exists(cache):
        return json.load(open(cache, "r", encoding="utf-8"))
    print("[API]" + url)
    req.urlretrieve(url, cache)
    time.sleep(1) # as a manner
    return json.load(open(cache, "r", encoding="utf-8"))


# Download Image

# In[9]:


def download_thumb(info, save_dir):
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    if info is None: return
    if not "photo" in info["info"]:
        print("[ERROR] broken info")
        return
    photolist = info["info"]["photo"]
    for photo in photolist:
        title = photo["photo_title"]
        photo_id = photo["photo_id"]
        url = photo["thumbnail_image_url"]
        path = save_dir + "/" + str(photo_id) + "_thumb.jpg"
        if os.path.exists(path):
            continue
        try:
            print("[download]", title, photo_id)
            req.urlretrieve(url, path)
            time.sleep(1) # as a manner
        except Exception as e:
            print("[ERROR] failed to download url=", url)


# Fetch all search result

# In[10]:


def download_all(keyword, save_dir, maxphoto = 1000):
    offset = 0
    limit = 100
    while True:
        #Call API
        info = search_photo(keyword, offset=offset, limit=limit)
        if info is None:
            print("[ERROR] no result");
            return
        if (not "info" in info) or (not "photo_num" in info["info"]):
            print("[ERROR] broken data");
            return
        photo_num = info["info"]["photo_num"]
        #Download if picture info is included
        print("*** download offset=", offset)
        download_thumb(info, save_dir)
        offset +- limit
        if offset >= maxphoto:
            break


# In[ ]:


if __name__ == "__main__":
    #execute alone use module
    download_all("ミニトマト", "./image/minitomato") 

